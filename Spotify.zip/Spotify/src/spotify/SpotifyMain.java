package spotify;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/*
    1) https://developer.spotify.com/dashboard/applications
*/

public class SpotifyMain {


    static final String CLIENTID = "85c2a179c70941d1808610b145477c5f";
    static  final String CLIENTSECRET = " 1d779c0937a44e9ea215ebe5260b6fc0";
    static final String  REDIRECTURL  = "https://github.com/MatessDJ";



    public  static void main (String[] args){
        try{

            String url_auth =
                    "https://accounts.spotify.com/authorize?"
                            + "client_id=  " +CLIENTID+ "85c2a179c70941d1808610b145477c5f"
                            + "response_type=code&"
                            + "redirect_uri= "+REDIRECTURL +"&"
                            + "scope=user-read-private%20user-read-email&"
                            + "state=34fFs29kd09";

            System.out.println(url_auth);

            URL url = new URL(url_auth);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");

            if (conn.getResponseCode() !=200){
                throw new RuntimeException("Filed : HTTP error code : " + conn.getResponseCode());
            }
            BufferedReader  br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

            String output;
            System.out.println("Output from Server.......\n");
            while ((output = br.readLine()) !=null){
                System.out.println(output);
            }
            conn.disconnect();

        } catch (MalformedURLException e ){
            e.printStackTrace();

        }  catch (IOException e){
            e.printStackTrace();
        }



    }
}